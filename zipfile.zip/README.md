# Secret Escapes - Tech Test

## Running the app

In the project directory, you'll need to first install the project's dependencies, run:

### `yarn install`

Once that's finished, you'll want to run the tests, so next run:

### `yarn test`

Finally to spin up the app on your local development server, run:

### `yarn start`

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
